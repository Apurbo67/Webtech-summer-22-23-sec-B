
<?php
    echo $_POST["email"];
?>