<!DOCTYPE html>
<html>
<head>
    <title>Complaints</title>
    
</head>
<body>
    <center>
        <div id="box">
            <h1>Complaints</h1>
            <form id="complaint-form" method="post">
                <label for="comment">Comment:</label><br>
                <textarea id="comment" name="comment" rows="4" cols="50"></textarea><br><br>
                <input type="submit" id="submit-btn" name="submit" value="Submit">
            </form>
            <p id="response-message" style="display: none; color: green;">Your Complaint was saved</p>
        </div>
    </center>


</body>
</html>
