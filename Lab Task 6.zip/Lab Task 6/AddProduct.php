
<?php
    if(!isset($_POST['save'])); 
    else{
        $name = $_POST['name'];
        $buyingprice = $_POST['buyingPrice'];
        $sellingprice = $_POST['sellingPrice'];
       

        $conn = mysqli_connect('localhost', 'root', '', 'product_db');
        $sql = "INSERT INTO products VALUES('$name', '$buyingprice', '$sellingprice');";

        mysqli_query($conn, $sql);
       
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
</head>
<body>
    <fieldset>
        <legend>Add Product</legend>
        
            <table>
                <tr>
                    <td>Name</td>
                </tr>
                <tr>
                    <td><input type="text" name="name" required></td>
                </tr>
                <tr>
                    <td>Buying Price</td>
                </tr>
                <tr>
                    <td><input type="text" name="buyingPrice" required></td>
                </tr>
                <tr>
                    <td>Selling Price</td>
                </tr>
                <tr>
                    <td><input type="text" name="sellingPrice" required></td>
                </tr>
                <tr>
                    <td><hr></td>
                </tr>
                <tr>
                    <td><input type="checkbox" name="display" value="true"> Display</td>
                </tr>
                <tr>
                    <td><hr></td>
                </tr>
                <tr>
                    <td><input type="submit" name="save" value="SAVE"></td>
                </tr>
            </table>
        </form>
    </fieldset>
</body>
</html>